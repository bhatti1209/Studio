﻿namespace GRE
{
    partial class NewTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.info1 = new System.Windows.Forms.Label();
            this.noofques = new System.Windows.Forms.TextBox();
            this.fillanswers = new System.Windows.Forms.Button();
            this.info2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.startbutton = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // info1
            // 
            this.info1.AutoSize = true;
            this.info1.Location = new System.Drawing.Point(30, 32);
            this.info1.Name = "info1";
            this.info1.Size = new System.Drawing.Size(217, 13);
            this.info1.TabIndex = 0;
            this.info1.Text = "Enter The Number Of Questions Paper Has :";
            // 
            // noofques
            // 
            this.noofques.Location = new System.Drawing.Point(253, 29);
            this.noofques.Name = "noofques";
            this.noofques.Size = new System.Drawing.Size(39, 20);
            this.noofques.TabIndex = 100;
            // 
            // fillanswers
            // 
            this.fillanswers.Location = new System.Drawing.Point(317, 27);
            this.fillanswers.Name = "fillanswers";
            this.fillanswers.Size = new System.Drawing.Size(75, 23);
            this.fillanswers.TabIndex = 102;
            this.fillanswers.Text = "Fill Answers";
            this.fillanswers.UseVisualStyleBackColor = true;
            this.fillanswers.Click += new System.EventHandler(this.fillanswers_Click);
            // 
            // info2
            // 
            this.info2.AutoSize = true;
            this.info2.Location = new System.Drawing.Point(77, 55);
            this.info2.Name = "info2";
            this.info2.Size = new System.Drawing.Size(128, 13);
            this.info2.TabIndex = 3;
            this.info2.Text = "(max. ques limit : 30 ques)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(118, 88);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(32, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Visible = false;
            this.textBox1.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(118, 114);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(32, 20);
            this.textBox2.TabIndex = 2;
            this.textBox2.Visible = false;
            this.textBox2.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "label2";
            this.label2.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(118, 139);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(32, 20);
            this.textBox3.TabIndex = 9;
            this.textBox3.Visible = false;
            this.textBox3.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(77, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "label3";
            this.label3.Visible = false;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(118, 163);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(32, 20);
            this.textBox4.TabIndex = 11;
            this.textBox4.Visible = false;
            this.textBox4.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(77, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "label4";
            this.label4.Visible = false;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(118, 189);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(32, 20);
            this.textBox5.TabIndex = 13;
            this.textBox5.Visible = false;
            this.textBox5.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(77, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "label5";
            this.label5.Visible = false;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(118, 215);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(32, 20);
            this.textBox6.TabIndex = 15;
            this.textBox6.Visible = false;
            this.textBox6.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(77, 218);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "label6";
            this.label6.Visible = false;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(118, 241);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(32, 20);
            this.textBox7.TabIndex = 17;
            this.textBox7.Visible = false;
            this.textBox7.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(77, 244);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "label7";
            this.label7.Visible = false;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(118, 267);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(32, 20);
            this.textBox8.TabIndex = 19;
            this.textBox8.Visible = false;
            this.textBox8.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(77, 270);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "label8";
            this.label8.Visible = false;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(118, 293);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(32, 20);
            this.textBox9.TabIndex = 21;
            this.textBox9.Visible = false;
            this.textBox9.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(77, 296);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "label9";
            this.label9.Visible = false;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(118, 319);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(32, 20);
            this.textBox10.TabIndex = 23;
            this.textBox10.Visible = false;
            this.textBox10.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(77, 322);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "label10";
            this.label10.Visible = false;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(215, 88);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(32, 20);
            this.textBox11.TabIndex = 43;
            this.textBox11.Visible = false;
            this.textBox11.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(174, 91);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 42;
            this.label11.Text = "label11";
            this.label11.Visible = false;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(215, 114);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(32, 20);
            this.textBox12.TabIndex = 41;
            this.textBox12.Visible = false;
            this.textBox12.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(174, 117);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 40;
            this.label12.Text = "label12";
            this.label12.Visible = false;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(215, 139);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(32, 20);
            this.textBox13.TabIndex = 39;
            this.textBox13.Visible = false;
            this.textBox13.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(174, 142);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 13);
            this.label13.TabIndex = 38;
            this.label13.Text = "label13";
            this.label13.Visible = false;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(215, 163);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(32, 20);
            this.textBox14.TabIndex = 37;
            this.textBox14.Visible = false;
            this.textBox14.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(174, 166);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 13);
            this.label14.TabIndex = 36;
            this.label14.Text = "label14";
            this.label14.Visible = false;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(215, 189);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(32, 20);
            this.textBox15.TabIndex = 35;
            this.textBox15.Visible = false;
            this.textBox15.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(174, 192);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 13);
            this.label15.TabIndex = 34;
            this.label15.Text = "label15";
            this.label15.Visible = false;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(215, 215);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(32, 20);
            this.textBox16.TabIndex = 33;
            this.textBox16.Visible = false;
            this.textBox16.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(174, 218);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "label16";
            this.label16.Visible = false;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(215, 241);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(32, 20);
            this.textBox17.TabIndex = 31;
            this.textBox17.Visible = false;
            this.textBox17.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(174, 244);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(41, 13);
            this.label17.TabIndex = 30;
            this.label17.Text = "label17";
            this.label17.Visible = false;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(215, 267);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(32, 20);
            this.textBox18.TabIndex = 29;
            this.textBox18.Visible = false;
            this.textBox18.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(174, 270);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 13);
            this.label18.TabIndex = 28;
            this.label18.Text = "label18";
            this.label18.Visible = false;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(215, 293);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(32, 20);
            this.textBox19.TabIndex = 27;
            this.textBox19.Visible = false;
            this.textBox19.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(174, 296);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 13);
            this.label19.TabIndex = 26;
            this.label19.Text = "label19";
            this.label19.Visible = false;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(215, 319);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(32, 20);
            this.textBox20.TabIndex = 25;
            this.textBox20.Visible = false;
            this.textBox20.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(174, 322);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 13);
            this.label20.TabIndex = 24;
            this.label20.Text = "label20";
            this.label20.Visible = false;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(317, 88);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(32, 20);
            this.textBox21.TabIndex = 63;
            this.textBox21.Visible = false;
            this.textBox21.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(276, 91);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 13);
            this.label21.TabIndex = 62;
            this.label21.Text = "label21";
            this.label21.Visible = false;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(317, 114);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(32, 20);
            this.textBox22.TabIndex = 61;
            this.textBox22.Visible = false;
            this.textBox22.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(276, 117);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 13);
            this.label22.TabIndex = 60;
            this.label22.Text = "label22";
            this.label22.Visible = false;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(317, 139);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(32, 20);
            this.textBox23.TabIndex = 59;
            this.textBox23.Visible = false;
            this.textBox23.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(276, 142);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 13);
            this.label23.TabIndex = 58;
            this.label23.Text = "label23";
            this.label23.Visible = false;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(317, 163);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(32, 20);
            this.textBox24.TabIndex = 57;
            this.textBox24.Visible = false;
            this.textBox24.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(276, 166);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 13);
            this.label24.TabIndex = 56;
            this.label24.Text = "label24";
            this.label24.Visible = false;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(317, 189);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(32, 20);
            this.textBox25.TabIndex = 55;
            this.textBox25.Visible = false;
            this.textBox25.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(276, 192);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 13);
            this.label25.TabIndex = 54;
            this.label25.Text = "label25";
            this.label25.Visible = false;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(317, 215);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(32, 20);
            this.textBox26.TabIndex = 53;
            this.textBox26.Visible = false;
            this.textBox26.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(276, 218);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 13);
            this.label26.TabIndex = 52;
            this.label26.Text = "label26";
            this.label26.Visible = false;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(317, 241);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(32, 20);
            this.textBox27.TabIndex = 51;
            this.textBox27.Visible = false;
            this.textBox27.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(276, 244);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 13);
            this.label27.TabIndex = 50;
            this.label27.Text = "label27";
            this.label27.Visible = false;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(317, 267);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(32, 20);
            this.textBox28.TabIndex = 49;
            this.textBox28.Visible = false;
            this.textBox28.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(276, 270);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(41, 13);
            this.label28.TabIndex = 48;
            this.label28.Text = "label28";
            this.label28.Visible = false;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(317, 293);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(32, 20);
            this.textBox29.TabIndex = 47;
            this.textBox29.Visible = false;
            this.textBox29.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(276, 296);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(41, 13);
            this.label29.TabIndex = 46;
            this.label29.Text = "label29";
            this.label29.Visible = false;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(317, 319);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(32, 20);
            this.textBox30.TabIndex = 45;
            this.textBox30.Visible = false;
            this.textBox30.TextChanged += new System.EventHandler(this.tabbing);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(276, 322);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 13);
            this.label30.TabIndex = 44;
            this.label30.Text = "label30";
            this.label30.Visible = false;
            // 
            // startbutton
            // 
            this.startbutton.Enabled = false;
            this.startbutton.Location = new System.Drawing.Point(172, 362);
            this.startbutton.Name = "startbutton";
            this.startbutton.Size = new System.Drawing.Size(75, 23);
            this.startbutton.TabIndex = 64;
            this.startbutton.Text = "Start Test";
            this.startbutton.UseVisualStyleBackColor = true;
            this.startbutton.Click += new System.EventHandler(this.startbutton_Click);
            // 
            // NewTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 403);
            this.Controls.Add(this.startbutton);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.info2);
            this.Controls.Add(this.fillanswers);
            this.Controls.Add(this.noofques);
            this.Controls.Add(this.info1);
            this.Name = "NewTest";
            this.Text = "NewTest";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label info1;
        private System.Windows.Forms.TextBox noofques;
        private System.Windows.Forms.Button fillanswers;
        private System.Windows.Forms.Label info2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button startbutton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}