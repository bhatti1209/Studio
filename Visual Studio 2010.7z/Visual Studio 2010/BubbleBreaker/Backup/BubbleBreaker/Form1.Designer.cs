namespace BubbleBreaker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.modesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.megashifterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.highscoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.clerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.smallToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.largeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox34 = new System.Windows.Forms.PictureBox();
            this.pictureBox35 = new System.Windows.Forms.PictureBox();
            this.pictureBox36 = new System.Windows.Forms.PictureBox();
            this.pictureBox37 = new System.Windows.Forms.PictureBox();
            this.pictureBox38 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox40 = new System.Windows.Forms.PictureBox();
            this.pictureBox41 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox43 = new System.Windows.Forms.PictureBox();
            this.pictureBox44 = new System.Windows.Forms.PictureBox();
            this.pictureBox45 = new System.Windows.Forms.PictureBox();
            this.pictureBox46 = new System.Windows.Forms.PictureBox();
            this.pictureBox47 = new System.Windows.Forms.PictureBox();
            this.pictureBox48 = new System.Windows.Forms.PictureBox();
            this.pictureBox49 = new System.Windows.Forms.PictureBox();
            this.pictureBox50 = new System.Windows.Forms.PictureBox();
            this.pictureBox51 = new System.Windows.Forms.PictureBox();
            this.pictureBox52 = new System.Windows.Forms.PictureBox();
            this.pictureBox53 = new System.Windows.Forms.PictureBox();
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.pictureBox70 = new System.Windows.Forms.PictureBox();
            this.pictureBox71 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.pictureBox75 = new System.Windows.Forms.PictureBox();
            this.pictureBox76 = new System.Windows.Forms.PictureBox();
            this.pictureBox77 = new System.Windows.Forms.PictureBox();
            this.pictureBox78 = new System.Windows.Forms.PictureBox();
            this.pictureBox79 = new System.Windows.Forms.PictureBox();
            this.pictureBox80 = new System.Windows.Forms.PictureBox();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.pictureBox82 = new System.Windows.Forms.PictureBox();
            this.pictureBox83 = new System.Windows.Forms.PictureBox();
            this.pictureBox84 = new System.Windows.Forms.PictureBox();
            this.pictureBox85 = new System.Windows.Forms.PictureBox();
            this.pictureBox86 = new System.Windows.Forms.PictureBox();
            this.pictureBox87 = new System.Windows.Forms.PictureBox();
            this.pictureBox88 = new System.Windows.Forms.PictureBox();
            this.pictureBox89 = new System.Windows.Forms.PictureBox();
            this.pictureBox90 = new System.Windows.Forms.PictureBox();
            this.pictureBox91 = new System.Windows.Forms.PictureBox();
            this.pictureBox92 = new System.Windows.Forms.PictureBox();
            this.pictureBox93 = new System.Windows.Forms.PictureBox();
            this.pictureBox94 = new System.Windows.Forms.PictureBox();
            this.pictureBox95 = new System.Windows.Forms.PictureBox();
            this.pictureBox96 = new System.Windows.Forms.PictureBox();
            this.pictureBox97 = new System.Windows.Forms.PictureBox();
            this.pictureBox98 = new System.Windows.Forms.PictureBox();
            this.pictureBox99 = new System.Windows.Forms.PictureBox();
            this.pictureBox100 = new System.Windows.Forms.PictureBox();
            this.pictureBox101 = new System.Windows.Forms.PictureBox();
            this.pictureBox102 = new System.Windows.Forms.PictureBox();
            this.pictureBox103 = new System.Windows.Forms.PictureBox();
            this.pictureBox104 = new System.Windows.Forms.PictureBox();
            this.pictureBox105 = new System.Windows.Forms.PictureBox();
            this.pictureBox106 = new System.Windows.Forms.PictureBox();
            this.pictureBox107 = new System.Windows.Forms.PictureBox();
            this.pictureBox108 = new System.Windows.Forms.PictureBox();
            this.pictureBox109 = new System.Windows.Forms.PictureBox();
            this.pictureBox110 = new System.Windows.Forms.PictureBox();
            this.pictureBox111 = new System.Windows.Forms.PictureBox();
            this.pictureBox112 = new System.Windows.Forms.PictureBox();
            this.pictureBox113 = new System.Windows.Forms.PictureBox();
            this.pictureBox114 = new System.Windows.Forms.PictureBox();
            this.pictureBox115 = new System.Windows.Forms.PictureBox();
            this.pictureBox116 = new System.Windows.Forms.PictureBox();
            this.pictureBox117 = new System.Windows.Forms.PictureBox();
            this.pictureBox118 = new System.Windows.Forms.PictureBox();
            this.pictureBox119 = new System.Windows.Forms.PictureBox();
            this.pictureBox120 = new System.Windows.Forms.PictureBox();
            this.shifterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.optionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(262, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem1,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newGameToolStripMenuItem1
            // 
            this.newGameToolStripMenuItem1.Name = "newGameToolStripMenuItem1";
            this.newGameToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.newGameToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.newGameToolStripMenuItem1.Text = "&New Game";
            this.newGameToolStripMenuItem1.Click += new System.EventHandler(this.newGameToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(152, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem1,
            this.modesToolStripMenuItem,
            this.toolStripMenuItem1,
            this.highscoresToolStripMenuItem,
            this.sizeToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.optionsToolStripMenuItem.Text = "&Options";
            // 
            // undoToolStripMenuItem1
            // 
            this.undoToolStripMenuItem1.Name = "undoToolStripMenuItem1";
            this.undoToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.undoToolStripMenuItem1.Size = new System.Drawing.Size(148, 22);
            this.undoToolStripMenuItem1.Text = "&Undo";
            this.undoToolStripMenuItem1.Click += new System.EventHandler(this.undoToolStripMenuItem1_Click);
            // 
            // modesToolStripMenuItem
            // 
            this.modesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.normalToolStripMenuItem,
            this.shifterToolStripMenuItem,
            this.megashifterToolStripMenuItem});
            this.modesToolStripMenuItem.Name = "modesToolStripMenuItem";
            this.modesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.modesToolStripMenuItem.Text = "&Modes";
            // 
            // normalToolStripMenuItem
            // 
            this.normalToolStripMenuItem.Checked = true;
            this.normalToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.normalToolStripMenuItem.Name = "normalToolStripMenuItem";
            this.normalToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.normalToolStripMenuItem.Text = "N&ormal";
            this.normalToolStripMenuItem.Click += new System.EventHandler(this.normalToolStripMenuItem_Click);
            // 
            // megashifterToolStripMenuItem
            // 
            this.megashifterToolStripMenuItem.Name = "megashifterToolStripMenuItem";
            this.megashifterToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.megashifterToolStripMenuItem.Text = "M&egashifter";
            this.megashifterToolStripMenuItem.Click += new System.EventHandler(this.megashifterToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(145, 6);
            // 
            // highscoresToolStripMenuItem
            // 
            this.highscoresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem,
            this.toolStripMenuItem3,
            this.clerToolStripMenuItem});
            this.highscoresToolStripMenuItem.Name = "highscoresToolStripMenuItem";
            this.highscoresToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.highscoresToolStripMenuItem.Text = "High&scores";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.viewToolStripMenuItem.Text = "Vi&ew";
            this.viewToolStripMenuItem.Click += new System.EventHandler(this.viewToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(107, 6);
            // 
            // clerToolStripMenuItem
            // 
            this.clerToolStripMenuItem.Name = "clerToolStripMenuItem";
            this.clerToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.clerToolStripMenuItem.Text = "&Clear";
            this.clerToolStripMenuItem.Click += new System.EventHandler(this.clerToolStripMenuItem_Click);
            // 
            // sizeToolStripMenuItem
            // 
            this.sizeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smallToolStripMenuItem,
            this.largeToolStripMenuItem});
            this.sizeToolStripMenuItem.Name = "sizeToolStripMenuItem";
            this.sizeToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.sizeToolStripMenuItem.Text = "S&ize";
            // 
            // smallToolStripMenuItem
            // 
            this.smallToolStripMenuItem.Checked = true;
            this.smallToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.smallToolStripMenuItem.Name = "smallToolStripMenuItem";
            this.smallToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.smallToolStripMenuItem.Text = "S&mall";
            this.smallToolStripMenuItem.Click += new System.EventHandler(this.smallToolStripMenuItem_Click);
            // 
            // largeToolStripMenuItem
            // 
            this.largeToolStripMenuItem.Name = "largeToolStripMenuItem";
            this.largeToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.largeToolStripMenuItem.Text = "&Large";
            this.largeToolStripMenuItem.Click += new System.EventHandler(this.largeToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Game Mode :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(144, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Normal";
            // 
            // pictureBox31
            // 
            this.pictureBox31.BackColor = System.Drawing.Color.White;
            this.pictureBox31.Location = new System.Drawing.Point(37, 188);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(20, 20);
            this.pictureBox31.TabIndex = 128;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Visible = false;
            this.pictureBox31.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox31.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox32
            // 
            this.pictureBox32.BackColor = System.Drawing.Color.White;
            this.pictureBox32.Location = new System.Drawing.Point(57, 188);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(20, 20);
            this.pictureBox32.TabIndex = 127;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Visible = false;
            this.pictureBox32.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox32.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox33
            // 
            this.pictureBox33.BackColor = System.Drawing.Color.White;
            this.pictureBox33.Location = new System.Drawing.Point(76, 188);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(20, 20);
            this.pictureBox33.TabIndex = 126;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Visible = false;
            this.pictureBox33.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox33.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox34
            // 
            this.pictureBox34.BackColor = System.Drawing.Color.White;
            this.pictureBox34.Location = new System.Drawing.Point(95, 188);
            this.pictureBox34.Name = "pictureBox34";
            this.pictureBox34.Size = new System.Drawing.Size(20, 20);
            this.pictureBox34.TabIndex = 125;
            this.pictureBox34.TabStop = false;
            this.pictureBox34.Visible = false;
            this.pictureBox34.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox34.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox35
            // 
            this.pictureBox35.BackColor = System.Drawing.Color.White;
            this.pictureBox35.Location = new System.Drawing.Point(114, 188);
            this.pictureBox35.Name = "pictureBox35";
            this.pictureBox35.Size = new System.Drawing.Size(20, 20);
            this.pictureBox35.TabIndex = 124;
            this.pictureBox35.TabStop = false;
            this.pictureBox35.Visible = false;
            this.pictureBox35.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox35.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox36
            // 
            this.pictureBox36.BackColor = System.Drawing.Color.White;
            this.pictureBox36.Location = new System.Drawing.Point(37, 172);
            this.pictureBox36.Name = "pictureBox36";
            this.pictureBox36.Size = new System.Drawing.Size(20, 20);
            this.pictureBox36.TabIndex = 123;
            this.pictureBox36.TabStop = false;
            this.pictureBox36.Visible = false;
            this.pictureBox36.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox36.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox37
            // 
            this.pictureBox37.BackColor = System.Drawing.Color.White;
            this.pictureBox37.Location = new System.Drawing.Point(57, 172);
            this.pictureBox37.Name = "pictureBox37";
            this.pictureBox37.Size = new System.Drawing.Size(20, 20);
            this.pictureBox37.TabIndex = 122;
            this.pictureBox37.TabStop = false;
            this.pictureBox37.Visible = false;
            this.pictureBox37.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox37.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox38
            // 
            this.pictureBox38.BackColor = System.Drawing.Color.White;
            this.pictureBox38.Location = new System.Drawing.Point(76, 172);
            this.pictureBox38.Name = "pictureBox38";
            this.pictureBox38.Size = new System.Drawing.Size(20, 20);
            this.pictureBox38.TabIndex = 121;
            this.pictureBox38.TabStop = false;
            this.pictureBox38.Visible = false;
            this.pictureBox38.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox38.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox39
            // 
            this.pictureBox39.BackColor = System.Drawing.Color.White;
            this.pictureBox39.Location = new System.Drawing.Point(95, 172);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(20, 20);
            this.pictureBox39.TabIndex = 120;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Visible = false;
            this.pictureBox39.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox39.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox40
            // 
            this.pictureBox40.BackColor = System.Drawing.Color.White;
            this.pictureBox40.Location = new System.Drawing.Point(114, 172);
            this.pictureBox40.Name = "pictureBox40";
            this.pictureBox40.Size = new System.Drawing.Size(20, 20);
            this.pictureBox40.TabIndex = 119;
            this.pictureBox40.TabStop = false;
            this.pictureBox40.Visible = false;
            this.pictureBox40.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox40.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox41
            // 
            this.pictureBox41.BackColor = System.Drawing.Color.White;
            this.pictureBox41.Location = new System.Drawing.Point(37, 154);
            this.pictureBox41.Name = "pictureBox41";
            this.pictureBox41.Size = new System.Drawing.Size(20, 20);
            this.pictureBox41.TabIndex = 118;
            this.pictureBox41.TabStop = false;
            this.pictureBox41.Visible = false;
            this.pictureBox41.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox41.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox42
            // 
            this.pictureBox42.BackColor = System.Drawing.Color.White;
            this.pictureBox42.Location = new System.Drawing.Point(57, 154);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(20, 20);
            this.pictureBox42.TabIndex = 117;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Visible = false;
            this.pictureBox42.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox42.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox43
            // 
            this.pictureBox43.BackColor = System.Drawing.Color.White;
            this.pictureBox43.Location = new System.Drawing.Point(76, 154);
            this.pictureBox43.Name = "pictureBox43";
            this.pictureBox43.Size = new System.Drawing.Size(20, 20);
            this.pictureBox43.TabIndex = 116;
            this.pictureBox43.TabStop = false;
            this.pictureBox43.Visible = false;
            this.pictureBox43.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox43.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox44
            // 
            this.pictureBox44.BackColor = System.Drawing.Color.White;
            this.pictureBox44.Location = new System.Drawing.Point(95, 154);
            this.pictureBox44.Name = "pictureBox44";
            this.pictureBox44.Size = new System.Drawing.Size(20, 20);
            this.pictureBox44.TabIndex = 115;
            this.pictureBox44.TabStop = false;
            this.pictureBox44.Visible = false;
            this.pictureBox44.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox44.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox45
            // 
            this.pictureBox45.BackColor = System.Drawing.Color.White;
            this.pictureBox45.Location = new System.Drawing.Point(114, 154);
            this.pictureBox45.Name = "pictureBox45";
            this.pictureBox45.Size = new System.Drawing.Size(20, 20);
            this.pictureBox45.TabIndex = 114;
            this.pictureBox45.TabStop = false;
            this.pictureBox45.Visible = false;
            this.pictureBox45.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox45.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox46
            // 
            this.pictureBox46.BackColor = System.Drawing.Color.White;
            this.pictureBox46.Location = new System.Drawing.Point(37, 133);
            this.pictureBox46.Name = "pictureBox46";
            this.pictureBox46.Size = new System.Drawing.Size(20, 20);
            this.pictureBox46.TabIndex = 113;
            this.pictureBox46.TabStop = false;
            this.pictureBox46.Visible = false;
            this.pictureBox46.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox46.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox47
            // 
            this.pictureBox47.BackColor = System.Drawing.Color.White;
            this.pictureBox47.Location = new System.Drawing.Point(57, 133);
            this.pictureBox47.Name = "pictureBox47";
            this.pictureBox47.Size = new System.Drawing.Size(20, 20);
            this.pictureBox47.TabIndex = 112;
            this.pictureBox47.TabStop = false;
            this.pictureBox47.Visible = false;
            this.pictureBox47.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox47.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox48
            // 
            this.pictureBox48.BackColor = System.Drawing.Color.White;
            this.pictureBox48.Location = new System.Drawing.Point(76, 133);
            this.pictureBox48.Name = "pictureBox48";
            this.pictureBox48.Size = new System.Drawing.Size(20, 20);
            this.pictureBox48.TabIndex = 111;
            this.pictureBox48.TabStop = false;
            this.pictureBox48.Visible = false;
            this.pictureBox48.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox48.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox49
            // 
            this.pictureBox49.BackColor = System.Drawing.Color.White;
            this.pictureBox49.Location = new System.Drawing.Point(95, 133);
            this.pictureBox49.Name = "pictureBox49";
            this.pictureBox49.Size = new System.Drawing.Size(20, 20);
            this.pictureBox49.TabIndex = 110;
            this.pictureBox49.TabStop = false;
            this.pictureBox49.Visible = false;
            this.pictureBox49.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox49.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox50
            // 
            this.pictureBox50.BackColor = System.Drawing.Color.White;
            this.pictureBox50.Location = new System.Drawing.Point(114, 133);
            this.pictureBox50.Name = "pictureBox50";
            this.pictureBox50.Size = new System.Drawing.Size(20, 20);
            this.pictureBox50.TabIndex = 109;
            this.pictureBox50.TabStop = false;
            this.pictureBox50.Visible = false;
            this.pictureBox50.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox50.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox51
            // 
            this.pictureBox51.BackColor = System.Drawing.Color.White;
            this.pictureBox51.Location = new System.Drawing.Point(37, 113);
            this.pictureBox51.Name = "pictureBox51";
            this.pictureBox51.Size = new System.Drawing.Size(20, 20);
            this.pictureBox51.TabIndex = 108;
            this.pictureBox51.TabStop = false;
            this.pictureBox51.Visible = false;
            this.pictureBox51.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox51.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox52
            // 
            this.pictureBox52.BackColor = System.Drawing.Color.White;
            this.pictureBox52.Location = new System.Drawing.Point(57, 113);
            this.pictureBox52.Name = "pictureBox52";
            this.pictureBox52.Size = new System.Drawing.Size(20, 20);
            this.pictureBox52.TabIndex = 107;
            this.pictureBox52.TabStop = false;
            this.pictureBox52.Visible = false;
            this.pictureBox52.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox52.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox53
            // 
            this.pictureBox53.BackColor = System.Drawing.Color.White;
            this.pictureBox53.Location = new System.Drawing.Point(76, 113);
            this.pictureBox53.Name = "pictureBox53";
            this.pictureBox53.Size = new System.Drawing.Size(20, 20);
            this.pictureBox53.TabIndex = 106;
            this.pictureBox53.TabStop = false;
            this.pictureBox53.Visible = false;
            this.pictureBox53.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox53.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox54
            // 
            this.pictureBox54.BackColor = System.Drawing.Color.White;
            this.pictureBox54.Location = new System.Drawing.Point(95, 113);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(20, 20);
            this.pictureBox54.TabIndex = 105;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Visible = false;
            this.pictureBox54.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox54.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox55
            // 
            this.pictureBox55.BackColor = System.Drawing.Color.White;
            this.pictureBox55.Location = new System.Drawing.Point(114, 113);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(20, 20);
            this.pictureBox55.TabIndex = 104;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Visible = false;
            this.pictureBox55.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox55.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox56
            // 
            this.pictureBox56.BackColor = System.Drawing.Color.White;
            this.pictureBox56.Location = new System.Drawing.Point(37, 92);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(20, 20);
            this.pictureBox56.TabIndex = 103;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Visible = false;
            this.pictureBox56.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox56.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox57
            // 
            this.pictureBox57.BackColor = System.Drawing.Color.White;
            this.pictureBox57.Location = new System.Drawing.Point(57, 92);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(20, 20);
            this.pictureBox57.TabIndex = 102;
            this.pictureBox57.TabStop = false;
            this.pictureBox57.Visible = false;
            this.pictureBox57.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox57.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox58
            // 
            this.pictureBox58.BackColor = System.Drawing.Color.White;
            this.pictureBox58.Location = new System.Drawing.Point(76, 92);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(20, 20);
            this.pictureBox58.TabIndex = 101;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.Visible = false;
            this.pictureBox58.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox58.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox59
            // 
            this.pictureBox59.BackColor = System.Drawing.Color.White;
            this.pictureBox59.Location = new System.Drawing.Point(95, 92);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(20, 20);
            this.pictureBox59.TabIndex = 100;
            this.pictureBox59.TabStop = false;
            this.pictureBox59.Visible = false;
            this.pictureBox59.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox59.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox60
            // 
            this.pictureBox60.BackColor = System.Drawing.Color.White;
            this.pictureBox60.Location = new System.Drawing.Point(114, 92);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(20, 20);
            this.pictureBox60.TabIndex = 99;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.Visible = false;
            this.pictureBox60.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox60.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.White;
            this.pictureBox26.Location = new System.Drawing.Point(37, 209);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(20, 20);
            this.pictureBox26.TabIndex = 98;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Visible = false;
            this.pictureBox26.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox26.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.Color.White;
            this.pictureBox27.Location = new System.Drawing.Point(57, 209);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(20, 20);
            this.pictureBox27.TabIndex = 97;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Visible = false;
            this.pictureBox27.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox27.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackColor = System.Drawing.Color.White;
            this.pictureBox28.Location = new System.Drawing.Point(76, 209);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(20, 20);
            this.pictureBox28.TabIndex = 96;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Visible = false;
            this.pictureBox28.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox28.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.Color.White;
            this.pictureBox29.Location = new System.Drawing.Point(95, 209);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(20, 20);
            this.pictureBox29.TabIndex = 95;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Visible = false;
            this.pictureBox29.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox29.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox30
            // 
            this.pictureBox30.BackColor = System.Drawing.Color.White;
            this.pictureBox30.Location = new System.Drawing.Point(114, 209);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(20, 20);
            this.pictureBox30.TabIndex = 94;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Visible = false;
            this.pictureBox30.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox30.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.White;
            this.pictureBox21.Location = new System.Drawing.Point(37, 229);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(20, 20);
            this.pictureBox21.TabIndex = 93;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Visible = false;
            this.pictureBox21.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox21.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.Color.White;
            this.pictureBox22.Location = new System.Drawing.Point(57, 229);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(20, 20);
            this.pictureBox22.TabIndex = 92;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Visible = false;
            this.pictureBox22.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox22.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.White;
            this.pictureBox23.Location = new System.Drawing.Point(76, 229);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(20, 20);
            this.pictureBox23.TabIndex = 91;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Visible = false;
            this.pictureBox23.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox23.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.White;
            this.pictureBox24.Location = new System.Drawing.Point(95, 229);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(20, 20);
            this.pictureBox24.TabIndex = 90;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Visible = false;
            this.pictureBox24.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox24.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.White;
            this.pictureBox25.Location = new System.Drawing.Point(114, 229);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(20, 20);
            this.pictureBox25.TabIndex = 89;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Visible = false;
            this.pictureBox25.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox25.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.White;
            this.pictureBox20.Location = new System.Drawing.Point(114, 248);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(20, 20);
            this.pictureBox20.TabIndex = 88;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Visible = false;
            this.pictureBox20.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox20.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.White;
            this.pictureBox19.Location = new System.Drawing.Point(95, 248);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(20, 20);
            this.pictureBox19.TabIndex = 87;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Visible = false;
            this.pictureBox19.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox19.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.White;
            this.pictureBox18.Location = new System.Drawing.Point(76, 248);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(20, 20);
            this.pictureBox18.TabIndex = 86;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Visible = false;
            this.pictureBox18.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox18.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.White;
            this.pictureBox17.Location = new System.Drawing.Point(57, 248);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(20, 20);
            this.pictureBox17.TabIndex = 85;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Visible = false;
            this.pictureBox17.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox17.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.White;
            this.pictureBox16.Location = new System.Drawing.Point(37, 248);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(20, 20);
            this.pictureBox16.TabIndex = 84;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Visible = false;
            this.pictureBox16.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox16.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.White;
            this.pictureBox15.Location = new System.Drawing.Point(114, 268);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(20, 20);
            this.pictureBox15.TabIndex = 83;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Visible = false;
            this.pictureBox15.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox15.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.White;
            this.pictureBox14.Location = new System.Drawing.Point(95, 268);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(20, 20);
            this.pictureBox14.TabIndex = 82;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Visible = false;
            this.pictureBox14.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox14.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.White;
            this.pictureBox13.Location = new System.Drawing.Point(76, 268);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(20, 20);
            this.pictureBox13.TabIndex = 81;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Visible = false;
            this.pictureBox13.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox13.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.White;
            this.pictureBox12.Location = new System.Drawing.Point(57, 268);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(20, 20);
            this.pictureBox12.TabIndex = 80;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Visible = false;
            this.pictureBox12.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.White;
            this.pictureBox11.Location = new System.Drawing.Point(37, 268);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(20, 20);
            this.pictureBox11.TabIndex = 79;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Visible = false;
            this.pictureBox11.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox11.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.White;
            this.pictureBox10.Location = new System.Drawing.Point(114, 287);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(20, 20);
            this.pictureBox10.TabIndex = 78;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Visible = false;
            this.pictureBox10.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.White;
            this.pictureBox9.Location = new System.Drawing.Point(95, 287);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(20, 20);
            this.pictureBox9.TabIndex = 77;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Visible = false;
            this.pictureBox9.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.White;
            this.pictureBox8.Location = new System.Drawing.Point(76, 287);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(20, 20);
            this.pictureBox8.TabIndex = 76;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            this.pictureBox8.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.White;
            this.pictureBox7.Location = new System.Drawing.Point(57, 287);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(20, 20);
            this.pictureBox7.TabIndex = 75;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            this.pictureBox7.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.White;
            this.pictureBox6.Location = new System.Drawing.Point(37, 287);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(20, 20);
            this.pictureBox6.TabIndex = 74;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            this.pictureBox6.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.Location = new System.Drawing.Point(114, 306);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(20, 20);
            this.pictureBox5.TabIndex = 73;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            this.pictureBox5.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.White;
            this.pictureBox4.Location = new System.Drawing.Point(95, 306);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(20, 20);
            this.pictureBox4.TabIndex = 72;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            this.pictureBox4.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Location = new System.Drawing.Point(76, 306);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(20, 20);
            this.pictureBox3.TabIndex = 71;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            this.pictureBox3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Location = new System.Drawing.Point(57, 306);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 20);
            this.pictureBox2.TabIndex = 70;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            this.pictureBox2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(37, 306);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 20);
            this.pictureBox1.TabIndex = 69;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(202, 386);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 132;
            this.label4.Text = "0";
            this.label4.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(159, 386);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 131;
            this.label3.Text = "Total :";
            this.label3.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(81, 386);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 130;
            this.label5.Text = "0";
            this.label5.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 386);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 129;
            this.label6.Text = "Score :";
            this.label6.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(29, 412);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 133;
            this.textBox1.Text = "Bharat";
            this.textBox1.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(147, 410);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 134;
            this.button1.Text = "Enter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox61
            // 
            this.pictureBox61.BackColor = System.Drawing.Color.White;
            this.pictureBox61.Location = new System.Drawing.Point(131, 188);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(20, 20);
            this.pictureBox61.TabIndex = 146;
            this.pictureBox61.TabStop = false;
            this.pictureBox61.Visible = false;
            this.pictureBox61.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox61.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox62
            // 
            this.pictureBox62.BackColor = System.Drawing.Color.White;
            this.pictureBox62.Location = new System.Drawing.Point(131, 172);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(20, 20);
            this.pictureBox62.TabIndex = 145;
            this.pictureBox62.TabStop = false;
            this.pictureBox62.Visible = false;
            this.pictureBox62.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox62.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox63
            // 
            this.pictureBox63.BackColor = System.Drawing.Color.White;
            this.pictureBox63.Location = new System.Drawing.Point(131, 154);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(20, 20);
            this.pictureBox63.TabIndex = 144;
            this.pictureBox63.TabStop = false;
            this.pictureBox63.Visible = false;
            this.pictureBox63.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox63.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox64
            // 
            this.pictureBox64.BackColor = System.Drawing.Color.White;
            this.pictureBox64.Location = new System.Drawing.Point(131, 133);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(20, 20);
            this.pictureBox64.TabIndex = 143;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.Visible = false;
            this.pictureBox64.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox64.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox65
            // 
            this.pictureBox65.BackColor = System.Drawing.Color.White;
            this.pictureBox65.Location = new System.Drawing.Point(131, 113);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(20, 20);
            this.pictureBox65.TabIndex = 142;
            this.pictureBox65.TabStop = false;
            this.pictureBox65.Visible = false;
            this.pictureBox65.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox65.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox66
            // 
            this.pictureBox66.BackColor = System.Drawing.Color.White;
            this.pictureBox66.Location = new System.Drawing.Point(131, 92);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(20, 20);
            this.pictureBox66.TabIndex = 141;
            this.pictureBox66.TabStop = false;
            this.pictureBox66.Visible = false;
            this.pictureBox66.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox66.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox67
            // 
            this.pictureBox67.BackColor = System.Drawing.Color.White;
            this.pictureBox67.Location = new System.Drawing.Point(131, 209);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(20, 20);
            this.pictureBox67.TabIndex = 140;
            this.pictureBox67.TabStop = false;
            this.pictureBox67.Visible = false;
            this.pictureBox67.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox67.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox68
            // 
            this.pictureBox68.BackColor = System.Drawing.Color.White;
            this.pictureBox68.Location = new System.Drawing.Point(131, 229);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(20, 20);
            this.pictureBox68.TabIndex = 139;
            this.pictureBox68.TabStop = false;
            this.pictureBox68.Visible = false;
            this.pictureBox68.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox68.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox69
            // 
            this.pictureBox69.BackColor = System.Drawing.Color.White;
            this.pictureBox69.Location = new System.Drawing.Point(131, 248);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(20, 20);
            this.pictureBox69.TabIndex = 138;
            this.pictureBox69.TabStop = false;
            this.pictureBox69.Visible = false;
            this.pictureBox69.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox69.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox70
            // 
            this.pictureBox70.BackColor = System.Drawing.Color.White;
            this.pictureBox70.Location = new System.Drawing.Point(131, 268);
            this.pictureBox70.Name = "pictureBox70";
            this.pictureBox70.Size = new System.Drawing.Size(20, 20);
            this.pictureBox70.TabIndex = 137;
            this.pictureBox70.TabStop = false;
            this.pictureBox70.Visible = false;
            this.pictureBox70.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox70.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox71
            // 
            this.pictureBox71.BackColor = System.Drawing.Color.White;
            this.pictureBox71.Location = new System.Drawing.Point(131, 287);
            this.pictureBox71.Name = "pictureBox71";
            this.pictureBox71.Size = new System.Drawing.Size(20, 20);
            this.pictureBox71.TabIndex = 136;
            this.pictureBox71.TabStop = false;
            this.pictureBox71.Visible = false;
            this.pictureBox71.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox71.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox72
            // 
            this.pictureBox72.BackColor = System.Drawing.Color.White;
            this.pictureBox72.Location = new System.Drawing.Point(131, 306);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(20, 20);
            this.pictureBox72.TabIndex = 135;
            this.pictureBox72.TabStop = false;
            this.pictureBox72.Visible = false;
            this.pictureBox72.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox72.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox73
            // 
            this.pictureBox73.BackColor = System.Drawing.Color.White;
            this.pictureBox73.Location = new System.Drawing.Point(151, 188);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(20, 20);
            this.pictureBox73.TabIndex = 158;
            this.pictureBox73.TabStop = false;
            this.pictureBox73.Visible = false;
            this.pictureBox73.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox73.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox74
            // 
            this.pictureBox74.BackColor = System.Drawing.Color.White;
            this.pictureBox74.Location = new System.Drawing.Point(151, 172);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(20, 20);
            this.pictureBox74.TabIndex = 157;
            this.pictureBox74.TabStop = false;
            this.pictureBox74.Visible = false;
            this.pictureBox74.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox74.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox75
            // 
            this.pictureBox75.BackColor = System.Drawing.Color.White;
            this.pictureBox75.Location = new System.Drawing.Point(151, 154);
            this.pictureBox75.Name = "pictureBox75";
            this.pictureBox75.Size = new System.Drawing.Size(20, 20);
            this.pictureBox75.TabIndex = 156;
            this.pictureBox75.TabStop = false;
            this.pictureBox75.Visible = false;
            this.pictureBox75.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox75.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox76
            // 
            this.pictureBox76.BackColor = System.Drawing.Color.White;
            this.pictureBox76.Location = new System.Drawing.Point(151, 133);
            this.pictureBox76.Name = "pictureBox76";
            this.pictureBox76.Size = new System.Drawing.Size(20, 20);
            this.pictureBox76.TabIndex = 155;
            this.pictureBox76.TabStop = false;
            this.pictureBox76.Visible = false;
            this.pictureBox76.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox76.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox77
            // 
            this.pictureBox77.BackColor = System.Drawing.Color.White;
            this.pictureBox77.Location = new System.Drawing.Point(151, 113);
            this.pictureBox77.Name = "pictureBox77";
            this.pictureBox77.Size = new System.Drawing.Size(20, 20);
            this.pictureBox77.TabIndex = 154;
            this.pictureBox77.TabStop = false;
            this.pictureBox77.Visible = false;
            this.pictureBox77.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox77.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox78
            // 
            this.pictureBox78.BackColor = System.Drawing.Color.White;
            this.pictureBox78.Location = new System.Drawing.Point(151, 92);
            this.pictureBox78.Name = "pictureBox78";
            this.pictureBox78.Size = new System.Drawing.Size(20, 20);
            this.pictureBox78.TabIndex = 153;
            this.pictureBox78.TabStop = false;
            this.pictureBox78.Visible = false;
            this.pictureBox78.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox78.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox79
            // 
            this.pictureBox79.BackColor = System.Drawing.Color.White;
            this.pictureBox79.Location = new System.Drawing.Point(151, 209);
            this.pictureBox79.Name = "pictureBox79";
            this.pictureBox79.Size = new System.Drawing.Size(20, 20);
            this.pictureBox79.TabIndex = 152;
            this.pictureBox79.TabStop = false;
            this.pictureBox79.Visible = false;
            this.pictureBox79.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox79.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox80
            // 
            this.pictureBox80.BackColor = System.Drawing.Color.White;
            this.pictureBox80.Location = new System.Drawing.Point(151, 229);
            this.pictureBox80.Name = "pictureBox80";
            this.pictureBox80.Size = new System.Drawing.Size(20, 20);
            this.pictureBox80.TabIndex = 151;
            this.pictureBox80.TabStop = false;
            this.pictureBox80.Visible = false;
            this.pictureBox80.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox80.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox81
            // 
            this.pictureBox81.BackColor = System.Drawing.Color.White;
            this.pictureBox81.Location = new System.Drawing.Point(151, 248);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(20, 20);
            this.pictureBox81.TabIndex = 150;
            this.pictureBox81.TabStop = false;
            this.pictureBox81.Visible = false;
            this.pictureBox81.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox81.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox82
            // 
            this.pictureBox82.BackColor = System.Drawing.Color.White;
            this.pictureBox82.Location = new System.Drawing.Point(151, 268);
            this.pictureBox82.Name = "pictureBox82";
            this.pictureBox82.Size = new System.Drawing.Size(20, 20);
            this.pictureBox82.TabIndex = 149;
            this.pictureBox82.TabStop = false;
            this.pictureBox82.Visible = false;
            this.pictureBox82.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox82.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox83
            // 
            this.pictureBox83.BackColor = System.Drawing.Color.White;
            this.pictureBox83.Location = new System.Drawing.Point(151, 287);
            this.pictureBox83.Name = "pictureBox83";
            this.pictureBox83.Size = new System.Drawing.Size(20, 20);
            this.pictureBox83.TabIndex = 148;
            this.pictureBox83.TabStop = false;
            this.pictureBox83.Visible = false;
            this.pictureBox83.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox83.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox84
            // 
            this.pictureBox84.BackColor = System.Drawing.Color.White;
            this.pictureBox84.Location = new System.Drawing.Point(151, 306);
            this.pictureBox84.Name = "pictureBox84";
            this.pictureBox84.Size = new System.Drawing.Size(20, 20);
            this.pictureBox84.TabIndex = 147;
            this.pictureBox84.TabStop = false;
            this.pictureBox84.Visible = false;
            this.pictureBox84.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox84.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox85
            // 
            this.pictureBox85.BackColor = System.Drawing.Color.White;
            this.pictureBox85.Location = new System.Drawing.Point(171, 188);
            this.pictureBox85.Name = "pictureBox85";
            this.pictureBox85.Size = new System.Drawing.Size(20, 20);
            this.pictureBox85.TabIndex = 170;
            this.pictureBox85.TabStop = false;
            this.pictureBox85.Visible = false;
            this.pictureBox85.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox85.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox86
            // 
            this.pictureBox86.BackColor = System.Drawing.Color.White;
            this.pictureBox86.Location = new System.Drawing.Point(171, 172);
            this.pictureBox86.Name = "pictureBox86";
            this.pictureBox86.Size = new System.Drawing.Size(20, 20);
            this.pictureBox86.TabIndex = 169;
            this.pictureBox86.TabStop = false;
            this.pictureBox86.Visible = false;
            this.pictureBox86.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox86.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox87
            // 
            this.pictureBox87.BackColor = System.Drawing.Color.White;
            this.pictureBox87.Location = new System.Drawing.Point(171, 154);
            this.pictureBox87.Name = "pictureBox87";
            this.pictureBox87.Size = new System.Drawing.Size(20, 20);
            this.pictureBox87.TabIndex = 168;
            this.pictureBox87.TabStop = false;
            this.pictureBox87.Visible = false;
            this.pictureBox87.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox87.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox88
            // 
            this.pictureBox88.BackColor = System.Drawing.Color.White;
            this.pictureBox88.Location = new System.Drawing.Point(171, 133);
            this.pictureBox88.Name = "pictureBox88";
            this.pictureBox88.Size = new System.Drawing.Size(20, 20);
            this.pictureBox88.TabIndex = 167;
            this.pictureBox88.TabStop = false;
            this.pictureBox88.Visible = false;
            this.pictureBox88.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox88.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox89
            // 
            this.pictureBox89.BackColor = System.Drawing.Color.White;
            this.pictureBox89.Location = new System.Drawing.Point(171, 113);
            this.pictureBox89.Name = "pictureBox89";
            this.pictureBox89.Size = new System.Drawing.Size(20, 20);
            this.pictureBox89.TabIndex = 166;
            this.pictureBox89.TabStop = false;
            this.pictureBox89.Visible = false;
            this.pictureBox89.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox89.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox90
            // 
            this.pictureBox90.BackColor = System.Drawing.Color.White;
            this.pictureBox90.Location = new System.Drawing.Point(171, 92);
            this.pictureBox90.Name = "pictureBox90";
            this.pictureBox90.Size = new System.Drawing.Size(20, 20);
            this.pictureBox90.TabIndex = 165;
            this.pictureBox90.TabStop = false;
            this.pictureBox90.Visible = false;
            this.pictureBox90.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox90.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox91
            // 
            this.pictureBox91.BackColor = System.Drawing.Color.White;
            this.pictureBox91.Location = new System.Drawing.Point(171, 209);
            this.pictureBox91.Name = "pictureBox91";
            this.pictureBox91.Size = new System.Drawing.Size(20, 20);
            this.pictureBox91.TabIndex = 164;
            this.pictureBox91.TabStop = false;
            this.pictureBox91.Visible = false;
            this.pictureBox91.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox91.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox92
            // 
            this.pictureBox92.BackColor = System.Drawing.Color.White;
            this.pictureBox92.Location = new System.Drawing.Point(171, 229);
            this.pictureBox92.Name = "pictureBox92";
            this.pictureBox92.Size = new System.Drawing.Size(20, 20);
            this.pictureBox92.TabIndex = 163;
            this.pictureBox92.TabStop = false;
            this.pictureBox92.Visible = false;
            this.pictureBox92.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox92.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox93
            // 
            this.pictureBox93.BackColor = System.Drawing.Color.White;
            this.pictureBox93.Location = new System.Drawing.Point(171, 248);
            this.pictureBox93.Name = "pictureBox93";
            this.pictureBox93.Size = new System.Drawing.Size(20, 20);
            this.pictureBox93.TabIndex = 162;
            this.pictureBox93.TabStop = false;
            this.pictureBox93.Visible = false;
            this.pictureBox93.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox93.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox94
            // 
            this.pictureBox94.BackColor = System.Drawing.Color.White;
            this.pictureBox94.Location = new System.Drawing.Point(171, 268);
            this.pictureBox94.Name = "pictureBox94";
            this.pictureBox94.Size = new System.Drawing.Size(20, 20);
            this.pictureBox94.TabIndex = 161;
            this.pictureBox94.TabStop = false;
            this.pictureBox94.Visible = false;
            this.pictureBox94.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox94.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox95
            // 
            this.pictureBox95.BackColor = System.Drawing.Color.White;
            this.pictureBox95.Location = new System.Drawing.Point(171, 287);
            this.pictureBox95.Name = "pictureBox95";
            this.pictureBox95.Size = new System.Drawing.Size(20, 20);
            this.pictureBox95.TabIndex = 160;
            this.pictureBox95.TabStop = false;
            this.pictureBox95.Visible = false;
            this.pictureBox95.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox95.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox96
            // 
            this.pictureBox96.BackColor = System.Drawing.Color.White;
            this.pictureBox96.Location = new System.Drawing.Point(171, 306);
            this.pictureBox96.Name = "pictureBox96";
            this.pictureBox96.Size = new System.Drawing.Size(20, 20);
            this.pictureBox96.TabIndex = 159;
            this.pictureBox96.TabStop = false;
            this.pictureBox96.Visible = false;
            this.pictureBox96.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox96.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox97
            // 
            this.pictureBox97.BackColor = System.Drawing.Color.White;
            this.pictureBox97.Location = new System.Drawing.Point(190, 188);
            this.pictureBox97.Name = "pictureBox97";
            this.pictureBox97.Size = new System.Drawing.Size(20, 20);
            this.pictureBox97.TabIndex = 182;
            this.pictureBox97.TabStop = false;
            this.pictureBox97.Visible = false;
            this.pictureBox97.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox97.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox98
            // 
            this.pictureBox98.BackColor = System.Drawing.Color.White;
            this.pictureBox98.Location = new System.Drawing.Point(190, 172);
            this.pictureBox98.Name = "pictureBox98";
            this.pictureBox98.Size = new System.Drawing.Size(20, 20);
            this.pictureBox98.TabIndex = 181;
            this.pictureBox98.TabStop = false;
            this.pictureBox98.Visible = false;
            this.pictureBox98.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox98.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox99
            // 
            this.pictureBox99.BackColor = System.Drawing.Color.White;
            this.pictureBox99.Location = new System.Drawing.Point(190, 154);
            this.pictureBox99.Name = "pictureBox99";
            this.pictureBox99.Size = new System.Drawing.Size(20, 20);
            this.pictureBox99.TabIndex = 180;
            this.pictureBox99.TabStop = false;
            this.pictureBox99.Visible = false;
            this.pictureBox99.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox99.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox100
            // 
            this.pictureBox100.BackColor = System.Drawing.Color.White;
            this.pictureBox100.Location = new System.Drawing.Point(190, 133);
            this.pictureBox100.Name = "pictureBox100";
            this.pictureBox100.Size = new System.Drawing.Size(20, 20);
            this.pictureBox100.TabIndex = 179;
            this.pictureBox100.TabStop = false;
            this.pictureBox100.Visible = false;
            this.pictureBox100.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox100.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox101
            // 
            this.pictureBox101.BackColor = System.Drawing.Color.White;
            this.pictureBox101.Location = new System.Drawing.Point(190, 113);
            this.pictureBox101.Name = "pictureBox101";
            this.pictureBox101.Size = new System.Drawing.Size(20, 20);
            this.pictureBox101.TabIndex = 178;
            this.pictureBox101.TabStop = false;
            this.pictureBox101.Visible = false;
            this.pictureBox101.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox101.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox102
            // 
            this.pictureBox102.BackColor = System.Drawing.Color.White;
            this.pictureBox102.Location = new System.Drawing.Point(190, 92);
            this.pictureBox102.Name = "pictureBox102";
            this.pictureBox102.Size = new System.Drawing.Size(20, 20);
            this.pictureBox102.TabIndex = 177;
            this.pictureBox102.TabStop = false;
            this.pictureBox102.Visible = false;
            this.pictureBox102.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox102.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox103
            // 
            this.pictureBox103.BackColor = System.Drawing.Color.White;
            this.pictureBox103.Location = new System.Drawing.Point(190, 209);
            this.pictureBox103.Name = "pictureBox103";
            this.pictureBox103.Size = new System.Drawing.Size(20, 20);
            this.pictureBox103.TabIndex = 176;
            this.pictureBox103.TabStop = false;
            this.pictureBox103.Visible = false;
            this.pictureBox103.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox103.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox104
            // 
            this.pictureBox104.BackColor = System.Drawing.Color.White;
            this.pictureBox104.Location = new System.Drawing.Point(190, 229);
            this.pictureBox104.Name = "pictureBox104";
            this.pictureBox104.Size = new System.Drawing.Size(20, 20);
            this.pictureBox104.TabIndex = 175;
            this.pictureBox104.TabStop = false;
            this.pictureBox104.Visible = false;
            this.pictureBox104.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox104.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox105
            // 
            this.pictureBox105.BackColor = System.Drawing.Color.White;
            this.pictureBox105.Location = new System.Drawing.Point(190, 248);
            this.pictureBox105.Name = "pictureBox105";
            this.pictureBox105.Size = new System.Drawing.Size(20, 20);
            this.pictureBox105.TabIndex = 174;
            this.pictureBox105.TabStop = false;
            this.pictureBox105.Visible = false;
            this.pictureBox105.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox105.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox106
            // 
            this.pictureBox106.BackColor = System.Drawing.Color.White;
            this.pictureBox106.Location = new System.Drawing.Point(190, 268);
            this.pictureBox106.Name = "pictureBox106";
            this.pictureBox106.Size = new System.Drawing.Size(20, 20);
            this.pictureBox106.TabIndex = 173;
            this.pictureBox106.TabStop = false;
            this.pictureBox106.Visible = false;
            this.pictureBox106.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox106.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox107
            // 
            this.pictureBox107.BackColor = System.Drawing.Color.White;
            this.pictureBox107.Location = new System.Drawing.Point(190, 287);
            this.pictureBox107.Name = "pictureBox107";
            this.pictureBox107.Size = new System.Drawing.Size(20, 20);
            this.pictureBox107.TabIndex = 172;
            this.pictureBox107.TabStop = false;
            this.pictureBox107.Visible = false;
            this.pictureBox107.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox107.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox108
            // 
            this.pictureBox108.BackColor = System.Drawing.Color.White;
            this.pictureBox108.Location = new System.Drawing.Point(190, 306);
            this.pictureBox108.Name = "pictureBox108";
            this.pictureBox108.Size = new System.Drawing.Size(20, 20);
            this.pictureBox108.TabIndex = 171;
            this.pictureBox108.TabStop = false;
            this.pictureBox108.Visible = false;
            this.pictureBox108.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox108.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox109
            // 
            this.pictureBox109.BackColor = System.Drawing.Color.White;
            this.pictureBox109.Location = new System.Drawing.Point(211, 188);
            this.pictureBox109.Name = "pictureBox109";
            this.pictureBox109.Size = new System.Drawing.Size(20, 20);
            this.pictureBox109.TabIndex = 194;
            this.pictureBox109.TabStop = false;
            this.pictureBox109.Visible = false;
            this.pictureBox109.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox109.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox110
            // 
            this.pictureBox110.BackColor = System.Drawing.Color.White;
            this.pictureBox110.Location = new System.Drawing.Point(211, 172);
            this.pictureBox110.Name = "pictureBox110";
            this.pictureBox110.Size = new System.Drawing.Size(20, 20);
            this.pictureBox110.TabIndex = 193;
            this.pictureBox110.TabStop = false;
            this.pictureBox110.Visible = false;
            this.pictureBox110.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox110.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox111
            // 
            this.pictureBox111.BackColor = System.Drawing.Color.White;
            this.pictureBox111.Location = new System.Drawing.Point(211, 154);
            this.pictureBox111.Name = "pictureBox111";
            this.pictureBox111.Size = new System.Drawing.Size(20, 20);
            this.pictureBox111.TabIndex = 192;
            this.pictureBox111.TabStop = false;
            this.pictureBox111.Visible = false;
            this.pictureBox111.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox111.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox112
            // 
            this.pictureBox112.BackColor = System.Drawing.Color.White;
            this.pictureBox112.Location = new System.Drawing.Point(211, 133);
            this.pictureBox112.Name = "pictureBox112";
            this.pictureBox112.Size = new System.Drawing.Size(20, 20);
            this.pictureBox112.TabIndex = 191;
            this.pictureBox112.TabStop = false;
            this.pictureBox112.Visible = false;
            this.pictureBox112.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox112.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox113
            // 
            this.pictureBox113.BackColor = System.Drawing.Color.White;
            this.pictureBox113.Location = new System.Drawing.Point(211, 113);
            this.pictureBox113.Name = "pictureBox113";
            this.pictureBox113.Size = new System.Drawing.Size(20, 20);
            this.pictureBox113.TabIndex = 190;
            this.pictureBox113.TabStop = false;
            this.pictureBox113.Visible = false;
            this.pictureBox113.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox113.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox114
            // 
            this.pictureBox114.BackColor = System.Drawing.Color.White;
            this.pictureBox114.Location = new System.Drawing.Point(211, 92);
            this.pictureBox114.Name = "pictureBox114";
            this.pictureBox114.Size = new System.Drawing.Size(20, 20);
            this.pictureBox114.TabIndex = 189;
            this.pictureBox114.TabStop = false;
            this.pictureBox114.Visible = false;
            this.pictureBox114.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox114.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox115
            // 
            this.pictureBox115.BackColor = System.Drawing.Color.White;
            this.pictureBox115.Location = new System.Drawing.Point(211, 209);
            this.pictureBox115.Name = "pictureBox115";
            this.pictureBox115.Size = new System.Drawing.Size(20, 20);
            this.pictureBox115.TabIndex = 188;
            this.pictureBox115.TabStop = false;
            this.pictureBox115.Visible = false;
            this.pictureBox115.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox115.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox116
            // 
            this.pictureBox116.BackColor = System.Drawing.Color.White;
            this.pictureBox116.Location = new System.Drawing.Point(211, 229);
            this.pictureBox116.Name = "pictureBox116";
            this.pictureBox116.Size = new System.Drawing.Size(20, 20);
            this.pictureBox116.TabIndex = 187;
            this.pictureBox116.TabStop = false;
            this.pictureBox116.Visible = false;
            this.pictureBox116.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox116.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox117
            // 
            this.pictureBox117.BackColor = System.Drawing.Color.White;
            this.pictureBox117.Location = new System.Drawing.Point(211, 248);
            this.pictureBox117.Name = "pictureBox117";
            this.pictureBox117.Size = new System.Drawing.Size(20, 20);
            this.pictureBox117.TabIndex = 186;
            this.pictureBox117.TabStop = false;
            this.pictureBox117.Visible = false;
            this.pictureBox117.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox117.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox118
            // 
            this.pictureBox118.BackColor = System.Drawing.Color.White;
            this.pictureBox118.Location = new System.Drawing.Point(211, 268);
            this.pictureBox118.Name = "pictureBox118";
            this.pictureBox118.Size = new System.Drawing.Size(20, 20);
            this.pictureBox118.TabIndex = 185;
            this.pictureBox118.TabStop = false;
            this.pictureBox118.Visible = false;
            this.pictureBox118.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox118.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox119
            // 
            this.pictureBox119.BackColor = System.Drawing.Color.White;
            this.pictureBox119.Location = new System.Drawing.Point(211, 287);
            this.pictureBox119.Name = "pictureBox119";
            this.pictureBox119.Size = new System.Drawing.Size(20, 20);
            this.pictureBox119.TabIndex = 184;
            this.pictureBox119.TabStop = false;
            this.pictureBox119.Visible = false;
            this.pictureBox119.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox119.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // pictureBox120
            // 
            this.pictureBox120.BackColor = System.Drawing.Color.White;
            this.pictureBox120.Location = new System.Drawing.Point(211, 306);
            this.pictureBox120.Name = "pictureBox120";
            this.pictureBox120.Size = new System.Drawing.Size(20, 20);
            this.pictureBox120.TabIndex = 183;
            this.pictureBox120.TabStop = false;
            this.pictureBox120.Visible = false;
            this.pictureBox120.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.doubleclicked);
            this.pictureBox120.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clicked);
            // 
            // shifterToolStripMenuItem
            // 
            this.shifterToolStripMenuItem.Name = "shifterToolStripMenuItem";
            this.shifterToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.shifterToolStripMenuItem.Text = "Shifter";
            this.shifterToolStripMenuItem.Click += new System.EventHandler(this.shifterToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(262, 445);
            this.Controls.Add(this.pictureBox109);
            this.Controls.Add(this.pictureBox110);
            this.Controls.Add(this.pictureBox111);
            this.Controls.Add(this.pictureBox112);
            this.Controls.Add(this.pictureBox113);
            this.Controls.Add(this.pictureBox114);
            this.Controls.Add(this.pictureBox115);
            this.Controls.Add(this.pictureBox116);
            this.Controls.Add(this.pictureBox117);
            this.Controls.Add(this.pictureBox118);
            this.Controls.Add(this.pictureBox119);
            this.Controls.Add(this.pictureBox120);
            this.Controls.Add(this.pictureBox97);
            this.Controls.Add(this.pictureBox98);
            this.Controls.Add(this.pictureBox99);
            this.Controls.Add(this.pictureBox100);
            this.Controls.Add(this.pictureBox101);
            this.Controls.Add(this.pictureBox102);
            this.Controls.Add(this.pictureBox103);
            this.Controls.Add(this.pictureBox104);
            this.Controls.Add(this.pictureBox105);
            this.Controls.Add(this.pictureBox106);
            this.Controls.Add(this.pictureBox107);
            this.Controls.Add(this.pictureBox108);
            this.Controls.Add(this.pictureBox85);
            this.Controls.Add(this.pictureBox86);
            this.Controls.Add(this.pictureBox87);
            this.Controls.Add(this.pictureBox88);
            this.Controls.Add(this.pictureBox89);
            this.Controls.Add(this.pictureBox90);
            this.Controls.Add(this.pictureBox91);
            this.Controls.Add(this.pictureBox92);
            this.Controls.Add(this.pictureBox93);
            this.Controls.Add(this.pictureBox94);
            this.Controls.Add(this.pictureBox95);
            this.Controls.Add(this.pictureBox96);
            this.Controls.Add(this.pictureBox73);
            this.Controls.Add(this.pictureBox74);
            this.Controls.Add(this.pictureBox75);
            this.Controls.Add(this.pictureBox76);
            this.Controls.Add(this.pictureBox77);
            this.Controls.Add(this.pictureBox78);
            this.Controls.Add(this.pictureBox79);
            this.Controls.Add(this.pictureBox80);
            this.Controls.Add(this.pictureBox81);
            this.Controls.Add(this.pictureBox82);
            this.Controls.Add(this.pictureBox83);
            this.Controls.Add(this.pictureBox84);
            this.Controls.Add(this.pictureBox61);
            this.Controls.Add(this.pictureBox62);
            this.Controls.Add(this.pictureBox63);
            this.Controls.Add(this.pictureBox64);
            this.Controls.Add(this.pictureBox65);
            this.Controls.Add(this.pictureBox66);
            this.Controls.Add(this.pictureBox67);
            this.Controls.Add(this.pictureBox68);
            this.Controls.Add(this.pictureBox69);
            this.Controls.Add(this.pictureBox70);
            this.Controls.Add(this.pictureBox71);
            this.Controls.Add(this.pictureBox72);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pictureBox33);
            this.Controls.Add(this.pictureBox34);
            this.Controls.Add(this.pictureBox35);
            this.Controls.Add(this.pictureBox36);
            this.Controls.Add(this.pictureBox37);
            this.Controls.Add(this.pictureBox38);
            this.Controls.Add(this.pictureBox39);
            this.Controls.Add(this.pictureBox40);
            this.Controls.Add(this.pictureBox41);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox43);
            this.Controls.Add(this.pictureBox44);
            this.Controls.Add(this.pictureBox45);
            this.Controls.Add(this.pictureBox46);
            this.Controls.Add(this.pictureBox47);
            this.Controls.Add(this.pictureBox48);
            this.Controls.Add(this.pictureBox49);
            this.Controls.Add(this.pictureBox50);
            this.Controls.Add(this.pictureBox51);
            this.Controls.Add(this.pictureBox52);
            this.Controls.Add(this.pictureBox53);
            this.Controls.Add(this.pictureBox54);
            this.Controls.Add(this.pictureBox55);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox57);
            this.Controls.Add(this.pictureBox58);
            this.Controls.Add(this.pictureBox59);
            this.Controls.Add(this.pictureBox60);
            this.Controls.Add(this.pictureBox26);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.pictureBox28);
            this.Controls.Add(this.pictureBox29);
            this.Controls.Add(this.pictureBox30);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bubble Breaker";
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox105)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox106)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox107)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox108)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox109)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox110)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox111)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox112)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox113)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox114)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox115)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox116)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox117)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox118)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox119)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox120)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem modesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem megashifterToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem highscoresToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox34;
        private System.Windows.Forms.PictureBox pictureBox35;
        private System.Windows.Forms.PictureBox pictureBox36;
        private System.Windows.Forms.PictureBox pictureBox37;
        private System.Windows.Forms.PictureBox pictureBox38;
        private System.Windows.Forms.PictureBox pictureBox39;
        private System.Windows.Forms.PictureBox pictureBox40;
        private System.Windows.Forms.PictureBox pictureBox41;
        private System.Windows.Forms.PictureBox pictureBox42;
        private System.Windows.Forms.PictureBox pictureBox43;
        private System.Windows.Forms.PictureBox pictureBox44;
        private System.Windows.Forms.PictureBox pictureBox45;
        private System.Windows.Forms.PictureBox pictureBox46;
        private System.Windows.Forms.PictureBox pictureBox47;
        private System.Windows.Forms.PictureBox pictureBox48;
        private System.Windows.Forms.PictureBox pictureBox49;
        private System.Windows.Forms.PictureBox pictureBox50;
        private System.Windows.Forms.PictureBox pictureBox51;
        private System.Windows.Forms.PictureBox pictureBox52;
        private System.Windows.Forms.PictureBox pictureBox53;
        private System.Windows.Forms.PictureBox pictureBox54;
        private System.Windows.Forms.PictureBox pictureBox55;
        private System.Windows.Forms.PictureBox pictureBox56;
        private System.Windows.Forms.PictureBox pictureBox57;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ToolStripMenuItem clerToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem sizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem smallToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem largeToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.PictureBox pictureBox62;
        private System.Windows.Forms.PictureBox pictureBox63;
        private System.Windows.Forms.PictureBox pictureBox64;
        private System.Windows.Forms.PictureBox pictureBox65;
        private System.Windows.Forms.PictureBox pictureBox66;
        private System.Windows.Forms.PictureBox pictureBox67;
        private System.Windows.Forms.PictureBox pictureBox68;
        private System.Windows.Forms.PictureBox pictureBox69;
        private System.Windows.Forms.PictureBox pictureBox70;
        private System.Windows.Forms.PictureBox pictureBox71;
        private System.Windows.Forms.PictureBox pictureBox72;
        private System.Windows.Forms.PictureBox pictureBox73;
        private System.Windows.Forms.PictureBox pictureBox74;
        private System.Windows.Forms.PictureBox pictureBox75;
        private System.Windows.Forms.PictureBox pictureBox76;
        private System.Windows.Forms.PictureBox pictureBox77;
        private System.Windows.Forms.PictureBox pictureBox78;
        private System.Windows.Forms.PictureBox pictureBox79;
        private System.Windows.Forms.PictureBox pictureBox80;
        private System.Windows.Forms.PictureBox pictureBox81;
        private System.Windows.Forms.PictureBox pictureBox82;
        private System.Windows.Forms.PictureBox pictureBox83;
        private System.Windows.Forms.PictureBox pictureBox84;
        private System.Windows.Forms.PictureBox pictureBox85;
        private System.Windows.Forms.PictureBox pictureBox86;
        private System.Windows.Forms.PictureBox pictureBox87;
        private System.Windows.Forms.PictureBox pictureBox88;
        private System.Windows.Forms.PictureBox pictureBox89;
        private System.Windows.Forms.PictureBox pictureBox90;
        private System.Windows.Forms.PictureBox pictureBox91;
        private System.Windows.Forms.PictureBox pictureBox92;
        private System.Windows.Forms.PictureBox pictureBox93;
        private System.Windows.Forms.PictureBox pictureBox94;
        private System.Windows.Forms.PictureBox pictureBox95;
        private System.Windows.Forms.PictureBox pictureBox96;
        private System.Windows.Forms.PictureBox pictureBox97;
        private System.Windows.Forms.PictureBox pictureBox98;
        private System.Windows.Forms.PictureBox pictureBox99;
        private System.Windows.Forms.PictureBox pictureBox100;
        private System.Windows.Forms.PictureBox pictureBox101;
        private System.Windows.Forms.PictureBox pictureBox102;
        private System.Windows.Forms.PictureBox pictureBox103;
        private System.Windows.Forms.PictureBox pictureBox104;
        private System.Windows.Forms.PictureBox pictureBox105;
        private System.Windows.Forms.PictureBox pictureBox106;
        private System.Windows.Forms.PictureBox pictureBox107;
        private System.Windows.Forms.PictureBox pictureBox108;
        private System.Windows.Forms.PictureBox pictureBox109;
        private System.Windows.Forms.PictureBox pictureBox110;
        private System.Windows.Forms.PictureBox pictureBox111;
        private System.Windows.Forms.PictureBox pictureBox112;
        private System.Windows.Forms.PictureBox pictureBox113;
        private System.Windows.Forms.PictureBox pictureBox114;
        private System.Windows.Forms.PictureBox pictureBox115;
        private System.Windows.Forms.PictureBox pictureBox116;
        private System.Windows.Forms.PictureBox pictureBox117;
        private System.Windows.Forms.PictureBox pictureBox118;
        private System.Windows.Forms.PictureBox pictureBox119;
        private System.Windows.Forms.PictureBox pictureBox120;
        private System.Windows.Forms.ToolStripMenuItem shifterToolStripMenuItem;

    }
}

